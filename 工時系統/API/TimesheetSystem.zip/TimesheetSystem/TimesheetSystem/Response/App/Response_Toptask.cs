﻿namespace TimesheetSystem.Response.App
{
    public class ListTopTaskResponse
    {
        public int id { get; set; }
        public string name { get; set; } = string.Empty;
        public decimal budget { get; set; }
        public string? managerName { get; set; }
        public DateTime createdAt { get; set; }
        public decimal actualHours { get; set; }
    }

    public class TopTaskDetailResponse
    {
        public int id { get; set; }
        public string name { get; set; } = string.Empty;
        public string? description { get; set; }
        public decimal budget { get; set; }

        public int managerId { get; set; }
        public string? managerName { get; set; }

        public int createdById { get; set; }
        public string? createdByName { get; set; }

        public int updatedById { get; set; }
        public string? updatedByName { get; set; }

        public DateTime createdAt { get; set; }
        public DateTime updatedAt { get; set; }

        public decimal actualHours { get; set; }
    }

    public class UpdateTopTaskResponse
    {
        public int id { get; set; }
        public string message { get; set; } = string.Empty;
        public DateTime updatedAt { get; set; }
    }

    public class CreateTopTaskResponse
    {
        public int id { get; set; }
        public string message { get; set; } = string.Empty;
        public DateTime createdAt { get; set; }
    }

    public class DeleteTopTaskResponse
    {
        public string deletedType { get; set; } = string.Empty; // "soft" or "hard"
        public int topTaskId { get; set; }

        // 兩者只會擇一有值
        public List<int>? softDeletedSubTaskIds { get; set; }
        public List<int>? hardDeletedSubTaskIds { get; set; }

        public DateTime deletedAt { get; set; }
    }
}
