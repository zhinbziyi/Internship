﻿namespace TimesheetSystem.Response.App
{
    public class AssigneeResponse
    {
        public int Id { get; set; }
        public string Name { get; set; }
    }
    public class ListSubtaskTreeResponse
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public int ParentId { get; set; }
        public int TopTaskId { get; set; }
        public string Status { get; set; }
        public double EstimatedHours { get; set; }
        public AssigneeResponse? Assignee { get; set; }
        public List<ListSubtaskTreeResponse> Children { get; set; } = new();
    }

    public class ListTopLevelSubtaskResponse
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public string Status { get; set; }
        public double EstimatedHours { get; set; }
        public AssigneeResponse? Assignee { get; set; }
    }

    public class ListSubtaskChildrenResponse
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public string Status { get; set; }
        public double EstimatedHours { get; set; }
        public AssigneeResponse? Assignee { get; set; }
    }

    public class SubtaskDetailResponse
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public string Description { get; set; }
        public int AssigneeId { get; set; }
        public string AssigneeName { get; set; }
        public string Status { get; set; }
        public double EstimatedHours { get; set; }
        public int CreatedById { get; set; }
        public string CreatedByName { get; set; }
        public int UpdatedById { get; set; }
        public string UpdatedByName { get; set; }
        public DateTime CreatedAt { get; set; }
        public DateTime UpdatedAt { get; set; }
    }

    public class UpdateSubtaskResponse
    {
        public int Id { get; set; }
        public string Message { get; set; }
        public DateTime UpdatedAt { get; set; }
    }

    public class CreateSubtaskResponse
    {
        public int Id { get; set; }
        public string Message { get; set; }
        public DateTime CreatedAt { get; set; }
    }

    public class DeleteSubtaskResponse
    {
        public string DeletedType { get; set; }
        public List<int> AllAffectedIds { get; set; } = new();
        public DateTime DeletedAt { get; set; }
    }
}
