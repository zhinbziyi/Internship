﻿namespace TimesheetSystem.Response.App
{
    public class EmployeeResponse
    {
        public int Id { get; set; }
        public string Name { get; set; }
    }
}
