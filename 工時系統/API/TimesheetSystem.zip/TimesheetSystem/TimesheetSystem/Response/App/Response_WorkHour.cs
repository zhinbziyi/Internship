﻿namespace TimesheetSystem.Response.App
{
    public class CreateWorkHourResponse
    {
        public int Id { get; set; }
        public int SubTaskId { get; set; }
        public int EmployeeId { get; set; }
        public decimal WorkHour { get; set; }
        public string? WorkDescription { get; set; }
        public DateTime CreatedAt { get; set; }
    }

    public class ListWorkHourResponse
    {
        public int Id { get; set; }
        public int SubTaskId { get; set; }
        public int EmployeeId { get; set; }
        public decimal WorkHour { get; set; }
        public string? WorkDescription { get; set; }
        public DateTime CreatedAt { get; set; }
        public DateTime UpdatedAt { get; set; }
    }

    public class UpdateWorkHourResponse
    {
        public int Id { get; set; }
        public int SubTaskId { get; set; }
        public int EmployeeId { get; set; }
        public decimal WorkHour { get; set; }
        public string? WorkDescription { get; set; }
        public DateTime CreatedAt { get; set; }
        public DateTime UpdatedAt { get; set; }
    }

    public class DeleteWorkHourResponse
    {
        public int Id { get; set; }
        public string? Message { get; set; }
    }
}
