﻿namespace TimesheetSystem.Response.Base
{
    public class Responser
    {
        public bool result { get; set; } = true;
        public int statusCode { get; set; } = 200;
        public string? msg { get; set; }
    }

    public class Responser<T>
    {
        public bool result { get; set; } = true;
        public int statusCode { get; set; } = 200;
        public string? msg { get; set; } = "成功";
        public T? data { get; set; }
    }
}
