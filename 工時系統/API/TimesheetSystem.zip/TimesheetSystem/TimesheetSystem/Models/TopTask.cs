﻿using System;
using System.Collections.Generic;

namespace TimesheetSystem.Models;

public partial class TopTask
{
    public int Id { get; set; }

    public string Name { get; set; } = null!;

    public string? Description { get; set; }

    public decimal? Budget { get; set; }

    public int? ManagerId { get; set; }

    public int? CreatedById { get; set; }

    public int? UpdatedById { get; set; }

    public DateTime? CreatedAt { get; set; }

    public DateTime? UpdatedAt { get; set; }

    public bool? IsDeleted { get; set; }

    public int? DeletedById { get; set; }

    public DateTime? DeletedAt { get; set; }
}
