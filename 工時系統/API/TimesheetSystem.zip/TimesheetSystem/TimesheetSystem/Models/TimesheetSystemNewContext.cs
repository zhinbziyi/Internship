﻿using System;
using System.Collections.Generic;
using Microsoft.EntityFrameworkCore;

namespace TimesheetSystem.Models;

public partial class TimesheetSystemNewContext : DbContext
{
    public TimesheetSystemNewContext()
    {

    }

    public TimesheetSystemNewContext(DbContextOptions<TimesheetSystemNewContext> options)
        : base(options)
    {
    }

    public virtual DbSet<Employee> Employees { get; set; }

    public virtual DbSet<SubTask> SubTasks { get; set; }

    public virtual DbSet<TopTask> TopTasks { get; set; }

    public virtual DbSet<WorkHour> WorkHours { get; set; }

    protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
#warning To protect potentially sensitive information in your connection string, you should move it out of source code. You can avoid scaffolding the connection string by using the Name= syntax to read it from configuration - see https://go.microsoft.com/fwlink/?linkid=2131148. For more guidance on storing connection strings, see https://go.microsoft.com/fwlink/?LinkId=723263.
        => optionsBuilder.UseSqlServer("Server=127.0.0.1;Database=TimesheetSystem_new;User ID=test;Password=000000;TrustServerCertificate=true");

    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
        modelBuilder.Entity<Employee>(entity =>
        {
            entity.HasKey(e => e.Id).HasName("PK__Employee__3213E83FFA887C24");

            entity.Property(e => e.Id).HasColumnName("id");
            entity.Property(e => e.Name).HasMaxLength(100);
        });

        modelBuilder.Entity<SubTask>(entity =>
        {
            entity.HasKey(e => e.Id).HasName("PK__SubTasks__3213E83F65BD561A");

            entity.Property(e => e.Id).HasColumnName("id");
            entity.Property(e => e.AssigneeId).HasColumnName("Assignee_Id");
            entity.Property(e => e.CreatedAt).HasColumnType("datetime");
            entity.Property(e => e.DeletedAt)
                .HasColumnType("datetime")
                .HasColumnName("DeletedAT");
            entity.Property(e => e.EstimatedHours)
                .HasColumnType("decimal(5, 2)")
                .HasColumnName("Estimated_Hours");
            entity.Property(e => e.Name).HasMaxLength(200);
            entity.Property(e => e.ParentId).HasColumnName("Parent_Id");
            entity.Property(e => e.Status).HasMaxLength(20);
            entity.Property(e => e.TopTaskId).HasColumnName("TopTask_Id");
            entity.Property(e => e.UpdatedAt).HasColumnType("datetime");
        });

        modelBuilder.Entity<TopTask>(entity =>
        {
            entity.HasKey(e => e.Id).HasName("PK__TopTasks__3213E83F264C1F43");

            entity.Property(e => e.Id).HasColumnName("id");
            entity.Property(e => e.Budget).HasColumnType("decimal(10, 2)");
            entity.Property(e => e.CreatedAt).HasColumnType("datetime");
            entity.Property(e => e.DeletedAt)
                .HasColumnType("datetime")
                .HasColumnName("DeletedAT");
            entity.Property(e => e.ManagerId).HasColumnName("Manager_Id");
            entity.Property(e => e.Name).HasMaxLength(100);
            entity.Property(e => e.UpdatedAt).HasColumnType("datetime");
        });

        modelBuilder.Entity<WorkHour>(entity =>
        {
            entity.HasKey(e => e.Id).HasName("PK__WorkHour__3213E83FC3F07A31");

            entity.Property(e => e.Id).HasColumnName("id");
            entity.Property(e => e.CreatedAt).HasColumnType("datetime");
            entity.Property(e => e.EmployeeId).HasColumnName("Employee_Id");
            entity.Property(e => e.SubTaskId).HasColumnName("SubTask_Id");
            entity.Property(e => e.UpdatedAt).HasColumnType("datetime");
            entity.Property(e => e.WordDescription).HasColumnName("Word_Description");
            entity.Property(e => e.WorkHour1)
                .HasColumnType("decimal(5, 2)")
                .HasColumnName("Work_Hour");
        });

        OnModelCreatingPartial(modelBuilder);
    }

    partial void OnModelCreatingPartial(ModelBuilder modelBuilder);
}
