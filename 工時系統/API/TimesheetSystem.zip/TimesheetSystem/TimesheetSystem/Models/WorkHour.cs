﻿using System;
using System.Collections.Generic;

namespace TimesheetSystem.Models;

public partial class WorkHour
{
    public int Id { get; set; }

    public int? SubTaskId { get; set; }

    public int? EmployeeId { get; set; }

    public decimal WorkHour1 { get; set; }

    public string? WordDescription { get; set; }

    public DateTime? CreatedAt { get; set; }

    public DateTime? UpdatedAt { get; set; }
}
