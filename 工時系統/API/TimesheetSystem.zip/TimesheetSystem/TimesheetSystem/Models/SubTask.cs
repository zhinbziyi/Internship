﻿using System;
using System.Collections.Generic;

namespace TimesheetSystem.Models;

public partial class SubTask
{
    public int Id { get; set; }

    public int ParentId { get; set; }

    public int TopTaskId { get; set; }

    public string Name { get; set; } = null!;

    public string? Description { get; set; }

    public decimal? EstimatedHours { get; set; }

    public int? AssigneeId { get; set; }

    public string? Status { get; set; }

    public int? CreatedById { get; set; }

    public int? UpdatedById { get; set; }

    public DateTime? CreatedAt { get; set; }

    public DateTime? UpdatedAt { get; set; }

    public bool? IsDeleted { get; set; }

    public int? DeletedById { get; set; }

    public DateTime? DeletedAt { get; set; }
}
