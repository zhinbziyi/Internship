﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using System;
using System.Linq;
using System.Threading.Tasks;
using TimesheetSystem.Models;
using TimesheetSystem.Request;       // CreateTopTaskRequest
using TimesheetSystem.Response.App; // CreateTopTaskResponse, ListTopTaskDto...
using TimesheetSystem.Response.Base;

namespace TimesheetSystem.Controllers
{
    [ApiController]
    [Route("api/toptasks/[action]")]
    public class ToptasksController : ControllerBase
    {
        private readonly TimesheetSystemNewContext _db;

        public ToptasksController(TimesheetSystemNewContext db)
            => _db = db;

        /// <summary>
        /// 取得所有專案（含/不含已刪除）
        /// POST api/toptasks/List
        /// </summary>
        [HttpPost]
        public async Task<ActionResult<Responser<List<ListTopTaskResponse>>>> List([FromBody] ListTopTaskRequest req)
        {
            // 1. 取專案清單
            var entities = await _db.TopTasks
                .AsNoTracking()
                .Where(x => req.includeDeleted || x.IsDeleted == false)
                .ToListAsync();

            // 2. 批次查 Manager 名稱
            var mgrIds = entities.Where(x => x.ManagerId.HasValue)
                                 .Select(x => x.ManagerId!.Value)
                                 .Distinct()
                                 .ToList();

            var empDict = await _db.Employees
                .AsNoTracking()
                .Where(e => mgrIds.Contains(e.Id))
                .ToDictionaryAsync(e => e.Id, e => e.Name);

            // 3. 批次聚合每個 TopTask 的實際工時
            var hoursByTopTask = await _db.WorkHours
                .AsNoTracking()
                .Join(_db.SubTasks.AsNoTracking(),
                      wh => wh.SubTaskId,            // 若 nullable，EF 會自動處理
                      st => st.Id,
                      (wh, st) => new { st.TopTaskId, st.IsDeleted, wh.WorkHour1 })
                //.Where(x => (bool)!x.IsDeleted)          // ← 若 SubTasks 有軟刪除，取消註解
                .GroupBy(x => x.TopTaskId)
                .Select(g => new {
                    TopTaskId = g.Key,
                    Total = g.Sum(x => (decimal?)x.WorkHour1) ?? 0m
                })
                .ToDictionaryAsync(x => x.TopTaskId, x => x.Total);

            // 4. 映射 DTO（把 actualHours 補上）
            var dtoList = entities.Select(x => new ListTopTaskResponse
            {
                id = x.Id,
                name = x.Name,
                budget = x.Budget.GetValueOrDefault(),
                managerName = x.ManagerId.HasValue && empDict.ContainsKey(x.ManagerId.Value)
                                ? empDict[x.ManagerId.Value]
                                : null,
                createdAt = x.CreatedAt.GetValueOrDefault(),
                actualHours = hoursByTopTask.TryGetValue(x.Id, out var h) ? h : 0m
            }).ToList();

            return Ok(new Responser<List<ListTopTaskResponse>> { data = dtoList });
        }


        /// <summary>
        /// 取得單一專案明細
        /// POST api/toptasks/Detail
        /// </summary>
        [HttpPost]
        public async Task<ActionResult<Responser<TopTaskDetailResponse>>> Detail([FromBody] TopTaskDetailRequest req)
        {
            var t = await _db.TopTasks
                .AsNoTracking()
                .FirstOrDefaultAsync(x => x.Id == req.id);

            if (t == null)
                return NotFound(new Responser<TopTaskDetailResponse>
                { result = false, statusCode = 404, msg = "TopTask not found" });

            // 1) 查名稱字典（維持你原本寫法）
            var userIds = new[] { t.ManagerId, t.CreatedById, t.UpdatedById }
                            .Where(id => id.HasValue).Select(id => id!.Value).Distinct().ToList();

            var users = await _db.Employees
                .AsNoTracking()
                .Where(e => userIds.Contains(e.Id))
                .ToDictionaryAsync(e => e.Id, e => e.Name);

            // 2) 計算該 TopTask 的實際總工時
            var actualHours = await _db.WorkHours
                .AsNoTracking()
                .Join(_db.SubTasks.AsNoTracking(),
                      wh => wh.SubTaskId,
                      st => st.Id,
                      (wh, st) => new { st.TopTaskId, st.IsDeleted, wh.WorkHour1 })
                .Where(x => x.TopTaskId == req.id /* && !x.IsDeleted */)   // 有軟刪除就加條件
                .SumAsync(x => (decimal?)x.WorkHour1) ?? 0m;

            // 3) 組 DTO
            var dto = new TopTaskDetailResponse
            {
                id = t.Id,
                name = t.Name,
                description = t.Description,
                budget = t.Budget.GetValueOrDefault(),
                managerId = t.ManagerId.GetValueOrDefault(),
                managerName = t.ManagerId.HasValue && users.ContainsKey(t.ManagerId.Value) ? users[t.ManagerId.Value] : null,
                createdById = t.CreatedById.GetValueOrDefault(),
                createdByName = t.CreatedById.HasValue && users.ContainsKey(t.CreatedById.Value) ? users[t.CreatedById.Value] : null,
                updatedById = t.UpdatedById.GetValueOrDefault(),
                updatedByName = t.UpdatedById.HasValue && users.ContainsKey(t.UpdatedById.Value) ? users[t.UpdatedById.Value] : null,
                createdAt = t.CreatedAt.GetValueOrDefault(),
                updatedAt = t.UpdatedAt ?? t.CreatedAt.GetValueOrDefault(),
                actualHours = actualHours                                // ← 新增
            };

            return Ok(new Responser<TopTaskDetailResponse> { data = dto });
        }



        /// <summary>
        /// 更新既有專案
        /// POST api/toptasks/Update
        /// </summary>
        [HttpPost]
        public async Task<ActionResult<Responser<UpdateTopTaskResponse>>> Update(
            [FromBody] UpdateTopTaskRequest req)
        {
            // 1. 取出欲更新的 TopTask
            var t = await _db.TopTasks
                .FirstOrDefaultAsync(x => x.Id == req.id);

            if (t == null)
            {
                return NotFound(new Responser<UpdateTopTaskResponse>
                {
                    result = false,
                    statusCode = 404,
                    msg = "TopTask not found"
                });
            }

            // 2. 套用更新欄位
            t.Name = req.name;
            t.Description = req.description;
            t.Budget = req.budget;
            t.ManagerId = req.managerId;
            t.UpdatedById = req.updatedById;
            t.UpdatedAt = DateTime.UtcNow;

            await _db.SaveChangesAsync();

            // 3. 組出回傳 DTO
            var resp = new UpdateTopTaskResponse
            {
                id = t.Id,
                message = "專案更新成功",
                updatedAt = t.UpdatedAt.Value
            };

            // 4. 回傳包在 Responser<T>
            return Ok(new Responser<UpdateTopTaskResponse>
            {
                data = resp
            });
        }


        /// <summary>
        /// 新增專案
        /// POST api/toptasks/Create
        /// </summary>
        [HttpPost]
        public async Task<ActionResult<Responser<CreateTopTaskResponse>>> Create(
            [FromBody] CreateTopTaskRequest req)
        {
            // 1. 轉換並建立 Entity
            var now = DateTime.UtcNow;
            var entity = new TopTask
            {
                Name = req.name,
                Description = req.description,
                Budget = req.budget,
                ManagerId = req.managerId,
                CreatedById = req.createdById,
                CreatedAt = now,
                IsDeleted = false
            };

            // 2. 新增至資料庫
            _db.TopTasks.Add(entity);
            await _db.SaveChangesAsync();

            // 3. 組出回傳 DTO
            var respPayload = new CreateTopTaskResponse
            {
                id = entity.Id,
                message = "專案新增成功",
                createdAt = now
            };

            // 4. 以 201 Created 回傳，並指向 Detail action
            return CreatedAtAction(
                nameof(Detail),
                new { req = new TopTaskDetailRequest { id = entity.Id } },
                new Responser<CreateTopTaskResponse> { data = respPayload }
            );
        }


        /// <summary>
        /// 刪除專案：支援多層巢狀子任務，頂層 parentId 為 0
        /// 有工時紀錄者軟刪，否則硬刪
        /// POST api/toptasks/Delete
        /// </summary>
        [HttpPost]
        public async Task<ActionResult<Responser<DeleteTopTaskResponse>>> Delete(
            [FromBody] DeleteTopTaskRequest req)
        {
            // 1. 取出專案
            var project = await _db.TopTasks
                .FirstOrDefaultAsync(x => x.Id == req.id);
            if (project == null)
                return NotFound(new Responser<DeleteTopTaskResponse>
                {
                    result = false,
                    statusCode = 404,
                    msg = "TopTask not found"
                });

            // 2. 撈出該專案所有子任務（所有層級）
            var allSubs = await _db.SubTasks
                .Where(st => st.TopTaskId == req.id)
                .ToListAsync();

            // 3. 建立 Parent→Children 索引（頂層 ParentId 就是 0）
            var childrenMap = allSubs
                .GroupBy(st => st.ParentId)          // 直接用 int
                .ToDictionary(g => g.Key, g => g.ToList());


            // 4. 遞迴收集所有 descendant IDs
            var allIds = new List<int>();
            void CollectDescendants(int parentId)
            {
                if (!childrenMap.ContainsKey(parentId)) return;
                foreach (var child in childrenMap[parentId])
                {
                    allIds.Add(child.Id);
                    CollectDescendants(child.Id);
                }
            }
            CollectDescendants(0);  // 從 0（代表 ParentId == null）開始

            // 5. 查哪些子任務已有工時
            var loggedSubIds = await _db.WorkHours
                .Where(wh => wh.SubTaskId.HasValue
                             && allIds.Contains(wh.SubTaskId.Value))   // 先判斷 HasValue 再取 Value
                .Select(wh => wh.SubTaskId.Value)                     // 取非 nullable 型別
                .Distinct()
                .ToListAsync();


            // 6. 分類軟刪與硬刪子任務
            var softDeletedSubTaskIds = new List<int>();
            var hardDeletedSubTaskIds = new List<int>();
            foreach (var st in allSubs)
            {
                if (loggedSubIds.Contains(st.Id))
                {
                    st.IsDeleted = true;
                    softDeletedSubTaskIds.Add(st.Id);
                }
                else
                {
                    hardDeletedSubTaskIds.Add(st.Id);
                }
            }

            // 7. 根據是否有任何已記錄的子任務，決定專案刪除方式
            bool anySoft = softDeletedSubTaskIds.Any();
            string deletedType;
            if (anySoft)
            {
                project.IsDeleted = true;
                project.UpdatedById = req.deletedById;
                project.UpdatedAt = DateTime.UtcNow;
                deletedType = "soft";
            }
            else
            {
                // 硬刪除：先刪除所有子任務，再刪除專案
                var hardSubs = allSubs.Where(st => hardDeletedSubTaskIds.Contains(st.Id));
                _db.SubTasks.RemoveRange(hardSubs);
                _db.TopTasks.Remove(project);
                deletedType = "hard";
            }

            // 8. Persist
            await _db.SaveChangesAsync();

            // 9. 回傳
            var payload = new DeleteTopTaskResponse
            {
                deletedType = deletedType,
                topTaskId = project.Id,
                softDeletedSubTaskIds = softDeletedSubTaskIds.Any() ? softDeletedSubTaskIds : null,
                hardDeletedSubTaskIds = hardDeletedSubTaskIds.Any() ? hardDeletedSubTaskIds : null,
                deletedAt = DateTime.UtcNow
            };
            return Ok(new Responser<DeleteTopTaskResponse> { data = payload });
        }


    }
}
