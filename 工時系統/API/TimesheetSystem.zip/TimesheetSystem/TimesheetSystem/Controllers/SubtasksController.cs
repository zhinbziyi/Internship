﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using TimesheetSystem.Models;
using TimesheetSystem.Request;          // ListSubtaskTreeRequest
using TimesheetSystem.Response.App;    // ListSubtaskTreeResponse, AssigneeResponse
using TimesheetSystem.Response.Base;   // Responser<T>

namespace TimesheetSystem.Controllers
{
    [ApiController]
    [Route("api/subtasks/[action]")]
    public class SubtasksController : ControllerBase
    {
        private readonly TimesheetSystemNewContext _db;
        public SubtasksController(TimesheetSystemNewContext db) => _db = db;

        /// <summary>
        /// 取得指定 TopTask 底下完整子任務樹
        /// POST api/subtasks/tree
        /// </summary>
        [HttpPost]
        public async Task<ActionResult<Responser<List<ListSubtaskTreeResponse>>>> Tree(
            [FromBody] ListSubtaskTreeRequest req)
        {
            // 1. 取得同一 TopTask 底下所有子任務
            var subs = await _db.SubTasks
                .AsNoTracking()
                .Where(st => st.TopTaskId == req.TopTaskId)
                .ToListAsync();

            // 2. 批次撈出 assignee 名稱對照表
            var assigneeIds = subs
                .Where(st => st.AssigneeId.HasValue)
                .Select(st => st.AssigneeId!.Value)
                .Distinct()
                .ToList();

            var assigneeDict = await _db.Employees
                .AsNoTracking()
                .Where(e => assigneeIds.Contains(e.Id))
                .ToDictionaryAsync(e => e.Id, e => e.Name);

            // 3. 建立 ParentId→子列表 的索引
            var childrenMap = subs
                .GroupBy(st => st.ParentId)
                .ToDictionary(g => g.Key, g => g.ToList());

            // 4. 遞迴建立 DTO 樹狀結構
            List<ListSubtaskTreeResponse> BuildTree(int parentId)
            {
                if (!childrenMap.ContainsKey(parentId))
                    return new List<ListSubtaskTreeResponse>();

                return childrenMap[parentId]
                    .Select(st =>
                    {
                        var node = new ListSubtaskTreeResponse
                        {
                            Id = st.Id,
                            Name = st.Name,
                            ParentId = st.ParentId,
                            TopTaskId = st.TopTaskId,
                            Status = st.Status,
                            EstimatedHours = (double)st.EstimatedHours.GetValueOrDefault(),
                            Assignee = st.AssigneeId.HasValue && assigneeDict.ContainsKey(st.AssigneeId.Value)
                                ? new AssigneeResponse
                                {
                                    Id = st.AssigneeId.Value,
                                    Name = assigneeDict[st.AssigneeId.Value]
                                }
                                : null
                        };
                        node.Children = BuildTree(st.Id);
                        return node;
                    })
                    .ToList();
            }

            var tree = BuildTree(0);

            // 5. 回傳結果
            return Ok(new Responser<List<ListSubtaskTreeResponse>>
            {
                data = tree
            });
        }


        /// <summary>
        /// 取得指定 TopTask 底下「第一層」子任務清單
        /// POST api/subtasks/top-level
        /// </summary>
        [HttpPost]
        public async Task<ActionResult<Responser<List<ListTopLevelSubtaskResponse>>>> TopLevel(
            [FromBody] ListTopLevelSubtaskRequest req)
        {
            // 1. 取出對應 TopTask 且 parentId == 0 的子任務
            var subs = await _db.SubTasks
                .AsNoTracking()
                .Where(st => st.TopTaskId == req.TopTaskId && st.ParentId == 0)
                .ToListAsync();

            // 2. 批次撈出 assignee 名稱對照表
            var assigneeIds = subs
                .Where(st => st.AssigneeId.HasValue)
                .Select(st => st.AssigneeId!.Value)
                .Distinct()
                .ToList();

            var assigneeDict = await _db.Employees
                .AsNoTracking()
                .Where(e => assigneeIds.Contains(e.Id))
                .ToDictionaryAsync(e => e.Id, e => e.Name);

            // 3. 映射成 DTO 列表
            var dtoList = subs.Select(st => new ListTopLevelSubtaskResponse
            {
                Id = st.Id,
                Name = st.Name,
                Status = st.Status,
                EstimatedHours = (double)st.EstimatedHours.GetValueOrDefault(),
                Assignee = st.AssigneeId.HasValue && assigneeDict.TryGetValue(st.AssigneeId.Value, out var nm)
                    ? new AssigneeResponse { Id = st.AssigneeId.Value, Name = nm }
                    : null
            }).ToList();

            // 4. 回傳結果
            return Ok(new Responser<List<ListTopLevelSubtaskResponse>>
            {
                data = dtoList
            });
        }


        /// <summary>
        /// 取得指定 parentId 底下所有子任務
        /// POST api/subtasks/children
        /// </summary>
        [HttpPost]
        public async Task<ActionResult<Responser<List<ListSubtaskChildrenResponse>>>> Children(
            [FromBody] ListSubtaskChildrenRequest req)
        {
            // 1. 撈出所有符合 parentId 的子任務
            var subs = await _db.SubTasks
                .AsNoTracking()
                .Where(st => st.ParentId == req.ParentId)
                .ToListAsync();

            // 2. 批次撈出 assignee 名稱對照表
            var assigneeIds = subs
                .Where(st => st.AssigneeId.HasValue)
                .Select(st => st.AssigneeId!.Value)
                .Distinct()
                .ToList();

            var assigneeDict = await _db.Employees
                .AsNoTracking()
                .Where(e => assigneeIds.Contains(e.Id))
                .ToDictionaryAsync(e => e.Id, e => e.Name);

            // 3. 映射成 DTO 列表
            var dtoList = subs
                .Select(st => new ListSubtaskChildrenResponse
                {
                    Id = st.Id,
                    Name = st.Name,
                    Status = st.Status,
                    EstimatedHours = (double)st.EstimatedHours.GetValueOrDefault(),
                    Assignee = st.AssigneeId.HasValue && assigneeDict.TryGetValue(st.AssigneeId.Value, out var name)
                        ? new AssigneeResponse { Id = st.AssigneeId.Value, Name = name }
                        : null
                })
                .ToList();

            // 4. 回傳結果
            return Ok(new Responser<List<ListSubtaskChildrenResponse>>
            {
                data = dtoList
            });
        }


        /// <summary>
        /// 取得指定 Subtask 詳細
        /// POST api/subtasks/detail
        /// </summary>
        [HttpPost]
        public async Task<ActionResult<Responser<SubtaskDetailResponse>>> Detail(
            [FromBody] SubtaskDetailRequest req)
        {
            // 1. 取出欲查詢的子任務
            var st = await _db.SubTasks
                .AsNoTracking()
                .FirstOrDefaultAsync(x => x.Id == req.SubTaskId);

            if (st == null)
            {
                return NotFound(new Responser<SubtaskDetailResponse>
                {
                    result = false,
                    statusCode = 404,
                    msg = "Subtask not found"
                });
            }

            // 2. 收集所有可能需要查名字的員工 Id
            var userIds = new[] { st.AssigneeId, st.CreatedById, st.UpdatedById }
                .Where(id => id.HasValue)
                .Select(id => id.Value)
                .Distinct()
                .ToList();

            var userDict = await _db.Employees
                .AsNoTracking()
                .Where(e => userIds.Contains(e.Id))
                .ToDictionaryAsync(e => e.Id, e => e.Name);

            // 3. 組出回傳 DTO
            var dto = new SubtaskDetailResponse
            {
                Id = st.Id,
                Name = st.Name,
                Description = st.Description,
                AssigneeId = st.AssigneeId.GetValueOrDefault(),
                AssigneeName = st.AssigneeId.HasValue && userDict.TryGetValue(st.AssigneeId.Value, out var aName)
                    ? aName
                    : null,
                Status = st.Status,
                EstimatedHours = (double)st.EstimatedHours.GetValueOrDefault(),
                CreatedById = st.CreatedById.GetValueOrDefault(),
                CreatedByName = st.CreatedById.HasValue && userDict.TryGetValue(st.CreatedById.Value, out var cName)
                    ? cName
                    : null,
                UpdatedById = st.UpdatedById.GetValueOrDefault(),
                UpdatedByName = st.UpdatedById.HasValue && userDict.TryGetValue(st.UpdatedById.Value, out var uName)
                    ? uName
                    : null,
                CreatedAt = st.CreatedAt.GetValueOrDefault(),
                UpdatedAt = st.UpdatedAt.GetValueOrDefault(st.CreatedAt.GetValueOrDefault())
            };

            // 4. 回傳結果
            return Ok(new Responser<SubtaskDetailResponse>
            {
                data = dto
            });
        }


        /// <summary>
        /// 更新指定 Subtask
        /// POST api/subtasks/update
        /// </summary>
        [HttpPost]
        public async Task<ActionResult<Responser<UpdateSubtaskResponse>>> Update(
            [FromBody] UpdateSubtaskRequest req)
        {
            // 1. 取出欲更新的 Subtask
            var st = await _db.SubTasks
                .FirstOrDefaultAsync(x => x.Id == req.Id);

            if (st == null)
            {
                return NotFound(new Responser<UpdateSubtaskResponse>
                {
                    result = false,
                    statusCode = 404,
                    msg = "Subtask not found"
                });
            }

            // 2. 套用更新欄位
            st.Name = req.Name;
            st.Description = req.Description;
            st.Status = req.Status;
            st.EstimatedHours = (decimal)req.EstimatedHours;  // 將 double 轉回 decimal
            st.AssigneeId = req.AssigneeId;
            st.UpdatedById = req.UpdatedById;
            st.UpdatedAt = DateTime.UtcNow;

            await _db.SaveChangesAsync();

            // 3. 組出回傳 DTO
            var resp = new UpdateSubtaskResponse
            {
                Id = st.Id,
                Message = "子任務更新成功",
                UpdatedAt = st.UpdatedAt.Value
            };

            // 4. 回傳包在 Responser<T>
            return Ok(new Responser<UpdateSubtaskResponse>
            {
                data = resp
            });
        }


        /// <summary>
        /// 新增子任務
        /// POST api/subtasks/create
        /// </summary>
        [HttpPost]
        public async Task<ActionResult<Responser<CreateSubtaskResponse>>> Create(
            [FromBody] CreateSubtaskRequest req)
        {
            // 1. 建立新的 SubTask Entity
            var now = DateTime.UtcNow;
            var entity = new SubTask
            {
                ParentId = req.ParentId,
                TopTaskId = req.TopTaskId,
                Name = req.Name,
                Description = req.Description,
                EstimatedHours = (decimal)req.EstimatedHours,  // DTO 用 double，Entity 用 decimal
                Status = req.Status,
                AssigneeId = req.AssigneeId,
                CreatedById = req.CreatedById,
                CreatedAt = now,
                IsDeleted = false
            };

            // 2. 寫入資料庫
            _db.SubTasks.Add(entity);
            await _db.SaveChangesAsync();

            // 3. 組出回傳 DTO
            var resp = new CreateSubtaskResponse
            {
                Id = entity.Id,
                Message = "子任務新增成功",
                CreatedAt = now
            };

            // 4. 以 201 Created 回傳，並指向 Detail action
            return CreatedAtAction(
                nameof(Detail),
                new { req = new SubtaskDetailRequest { SubTaskId = entity.Id } },
                new Responser<CreateSubtaskResponse> { data = resp }
            );
        }


        /// <summary>
        /// 刪除指定 Subtask（支援遞迴子節點），有工時者軟刪，否則硬刪
        /// POST api/subtasks/delete
        /// </summary>
        [HttpPost]
        public async Task<ActionResult<Responser<DeleteSubtaskResponse>>> Delete(
            [FromBody] DeleteSubtaskRequest req)
        {
            // 1. 取出目標 Subtask
            var root = await _db.SubTasks
                .FirstOrDefaultAsync(st => st.Id == req.Id);
            if (root == null)
                return NotFound(new Responser<DeleteSubtaskResponse>
                {
                    result = false,
                    statusCode = 404,
                    msg = "Subtask not found"
                });

            // 2. 撈出同一 TopTask 底下所有 Subtasks
            var allSubs = await _db.SubTasks
                .Where(st => st.TopTaskId == root.TopTaskId)
                .ToListAsync();

            // 3. 建立 ParentId → 子列表 索引
            var childrenMap = allSubs
                .GroupBy(st => st.ParentId)
                .ToDictionary(g => g.Key, g => g.ToList());

            // 4. 收集 root 節點的所有 descendant IDs
            var allIds = new List<int>();
            void Collect(int parentId)
            {
                if (!childrenMap.ContainsKey(parentId)) return;
                foreach (var c in childrenMap[parentId])
                {
                    allIds.Add(c.Id);
                    Collect(c.Id);
                }
            }
            Collect(root.Id);

            // 5. 查哪些 Subtask 已有工時紀錄
            var loggedSubIds = await _db.WorkHours
                .Where(wh => wh.SubTaskId.HasValue && allIds.Contains(wh.SubTaskId.Value))
                .Select(wh => wh.SubTaskId.Value)
                .Distinct()
                .ToListAsync();

            // 6. 分類
            var softDeleted = new List<int>();
            var hardDeleted = new List<int>();
            // 根節點也要考慮在內
            var targets = allSubs.Where(st => st.Id == root.Id || allIds.Contains(st.Id));
            foreach (var st in targets)
            {
                if (loggedSubIds.Contains(st.Id))
                {
                    st.IsDeleted = true;
                    st.UpdatedById = req.DeletedById;
                    st.UpdatedAt = DateTime.UtcNow;
                    softDeleted.Add(st.Id);
                }
                else
                {
                    hardDeleted.Add(st.Id);
                }
            }

            // 7. 決定刪除方式
            bool anySoft = softDeleted.Any();
            string deletedType;
            if (anySoft)
            {
                root.IsDeleted = true;
                root.UpdatedById = req.DeletedById;
                root.UpdatedAt = DateTime.UtcNow;
                deletedType = "soft";
                // children without logs 留存
            }
            else
            {
                // 硬刪除：移除所有無工時的節點
                var toHard = targets.Where(st => hardDeleted.Contains(st.Id));
                _db.SubTasks.RemoveRange(toHard);
                deletedType = "hard";
            }

            await _db.SaveChangesAsync();

            // 8. 回傳
            var resp = new DeleteSubtaskResponse
            {
                DeletedType = deletedType,
                AllAffectedIds = softDeleted.Concat(hardDeleted).ToList(),
                DeletedAt = DateTime.UtcNow
            };
            return Ok(new Responser<DeleteSubtaskResponse> { data = resp });
        }

    }
}
