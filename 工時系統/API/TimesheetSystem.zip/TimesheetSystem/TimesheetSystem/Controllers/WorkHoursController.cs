﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using System;
using System.Threading.Tasks;
using TimesheetSystem.Models;
using TimesheetSystem.Request;       // CreateWorkHourRequest
using TimesheetSystem.Response.App; // CreateWorkHourResponse
using TimesheetSystem.Response.Base; // Responser<T>

namespace TimesheetSystem.Controllers
{
    [ApiController]
    [Route("api/work-hours/[action]")]
    public class WorkHoursController : ControllerBase
    {
        private readonly TimesheetSystemNewContext _db;
        public WorkHoursController(TimesheetSystemNewContext db) => _db = db;

        /// <summary>
        /// 新增工時紀錄
        /// POST api/work-hours/Create
        /// </summary>
        [HttpPost]
        public async Task<ActionResult<Responser<CreateWorkHourResponse>>> Create(
            [FromBody] CreateWorkHourRequest req)
        {
            // 1. 準備時間
            var now = DateTime.UtcNow;

            // 2. 建立 Entity
            var entity = new WorkHour
            {
                SubTaskId = req.SubTaskId,
                EmployeeId = req.EmployeeId,
                WorkHour1 = req.WorkHour,
                WordDescription = req.WorkDescription,
                CreatedAt = req.CreatedAt == default
                                    ? now
                                    : req.CreatedAt
            };

            // 3. 寫入資料庫
            _db.WorkHours.Add(entity);
            await _db.SaveChangesAsync();

            // 4. 組出回傳 DTO
            var resp = new CreateWorkHourResponse
            {
                Id = entity.Id,
                SubTaskId = entity.SubTaskId.GetValueOrDefault(),
                EmployeeId = entity.EmployeeId.GetValueOrDefault(),
                WorkHour = entity.WorkHour1,      // 或是 WorkHour, 視你 Model 屬性而定
                WorkDescription = entity.WordDescription,
                CreatedAt = entity.CreatedAt.GetValueOrDefault()
            };


            // 5. 回傳結果
            return Ok(new Responser<CreateWorkHourResponse>
            {
                data = resp
            });
        }

        /// <summary>
        /// 列出工時紀錄，可依 SubTaskId、EmployeeId 篩選
        /// POST api/work-hours/List
        /// </summary>
        [HttpPost]
        public async Task<ActionResult<Responser<List<ListWorkHourResponse>>>> List(
            [FromBody] ListWorkHourRequest req)
        {
            // 1. 建立 Query 並套用篩選
            var query = _db.WorkHours
                .AsNoTracking()
                .AsQueryable();

            if (req.SubTaskId.HasValue)
                query = query.Where(w => w.SubTaskId == req.SubTaskId.Value);
            if (req.EmployeeId.HasValue)
                query = query.Where(w => w.EmployeeId == req.EmployeeId.Value);

            // 2. 取出資料
            var list = await query
                .OrderByDescending(w => w.CreatedAt)
                .ToListAsync();

            // 3. 映射成 DTO 列表
            var dtoList = list.Select(w => new ListWorkHourResponse
            {
                Id = w.Id,
                SubTaskId = w.SubTaskId.GetValueOrDefault(),
                EmployeeId = w.EmployeeId.GetValueOrDefault(),
                WorkHour = w.WorkHour1,  // 或 w.WorkHour，視你的 Entity 屬性而定
                WorkDescription = w.WordDescription,
                CreatedAt = w.CreatedAt.GetValueOrDefault(),
                UpdatedAt = w.UpdatedAt.GetValueOrDefault()
            }).ToList();

            // 4. 回傳
            return Ok(new Responser<List<ListWorkHourResponse>>
            {
                data = dtoList
            });
        }


        /// <summary>
        /// 更新工時紀錄（限更新自己的工時且必須在職）
        /// POST api/work-hours/Update
        /// </summary>
        [HttpPost]
        public async Task<ActionResult<Responser<UpdateWorkHourResponse>>> Update(
            [FromBody] UpdateWorkHourRequest req)
        {
            // 1. 取出欲更新的 WorkHour
            var w = await _db.WorkHours
                .FirstOrDefaultAsync(x => x.Id == req.Id);

            if (w == null)
                return NotFound(new Responser<UpdateWorkHourResponse>
                {
                    result = false,
                    statusCode = 404,
                    msg = "WorkHour not found"
                });

            // 2. 取出目前使用者 Id 的 Claim，並檢查
            var claim = User.FindFirst("employeeId");
            if (claim == null)
                return Unauthorized(new Responser<UpdateWorkHourResponse>
                {
                    result = false,
                    statusCode = 401,
                    msg = "未授權"
                });
            var currentUserId = int.Parse(claim.Value);

            // 3. 取出呼叫者在職狀態
            var me = await _db.Employees
                .AsNoTracking()
                .FirstOrDefaultAsync(e => e.Id == currentUserId);

            // 4. 權限檢查：必須是自己的工時，且員工必須在職
            if (w.EmployeeId.GetValueOrDefault() != currentUserId
                || me == null
                || !me.IsActive)
            {
                return Unauthorized(new Responser<UpdateWorkHourResponse>
                {
                    result = false,
                    statusCode = 401,
                    msg = "未授權"
                });
            }

            // 5. 更新欄位
            w.SubTaskId = req.SubTaskId;
            w.WorkHour1 = req.WorkHour;
            w.WordDescription = req.WorkDescription;
            w.CreatedAt = req.CreatedAt;
            w.UpdatedAt = DateTime.UtcNow;

            await _db.SaveChangesAsync();

            // 6. 組出回傳 DTO
            var resp = new UpdateWorkHourResponse
            {
                Id = w.Id,
                SubTaskId = w.SubTaskId.GetValueOrDefault(),
                EmployeeId = w.EmployeeId.GetValueOrDefault(),
                WorkHour = w.WorkHour1,
                WorkDescription = w.WordDescription,
                CreatedAt = w.CreatedAt.GetValueOrDefault(),
                UpdatedAt = w.UpdatedAt.GetValueOrDefault()
            };

            return Ok(new Responser<UpdateWorkHourResponse>
            {
                data = resp
            });
        }



        /// <summary>
        /// 刪除工時紀錄（硬刪除）
        /// POST api/work-hours/Delete
        /// </summary>
        [HttpPost]
        public async Task<ActionResult<Responser<DeleteWorkHourResponse>>> Delete(
    [FromBody] DeleteWorkHourRequest req)
        {
            var w = await _db.WorkHours.FirstOrDefaultAsync(x => x.Id == req.Id);
            if (w == null)
                return NotFound(new Responser<DeleteWorkHourResponse>
                {
                    result = false,
                    statusCode = 404,
                    msg = "WorkHour not found"
                });

            var claim = User.FindFirst("employeeId");
            if (claim == null)
                return Unauthorized(new Responser<DeleteWorkHourResponse>
                {
                    result = false,
                    statusCode = 401,
                    msg = "未授權"
                });
            var currentUserId = int.Parse(claim.Value);

            // 取出使用者在職狀態
            var me = await _db.Employees
                .AsNoTracking()
                .FirstOrDefaultAsync(e => e.Id == currentUserId);

            // 權限檢查：必須是自己的工時，且員工必須在職
            if (w.EmployeeId.GetValueOrDefault() != currentUserId
                || me == null
                || !me.IsActive)
            {
                return Unauthorized(new Responser<DeleteWorkHourResponse>
                {
                    result = false,
                    statusCode = 401,
                    msg = "未授權"
                });
            }

            _db.WorkHours.Remove(w);
            await _db.SaveChangesAsync();

            var resp = new DeleteWorkHourResponse
            {
                Id = req.Id,
                Message = "工時刪除成功"
            };
            return Ok(new Responser<DeleteWorkHourResponse> { data = resp });
        }
    }
}
