﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using TimesheetSystem.Models;
using TimesheetSystem.Request;        // ListEmployeesRequest
using TimesheetSystem.Response.App;   // EmployeeResponse
using TimesheetSystem.Response.Base;  // Responser<T>

namespace TimesheetSystem.Controllers
{
    [ApiController]
    [Route("api/employees/[action]")]
    public class EmployeesController : ControllerBase
    {
        private readonly TimesheetSystemNewContext _db;
        public EmployeesController(TimesheetSystemNewContext db) => _db = db;

        /// <summary>
        /// 讀取所有員工，用於下拉選單
        /// POST api/employees/list
        /// </summary>
        [HttpPost]
        public async Task<ActionResult<Responser<List<EmployeeResponse>>>> List(
            [FromBody] ListEmployeesRequest req)
        {
            var list = await _db.Employees
                .AsNoTracking()
                .Select(e => new EmployeeResponse
                {
                    Id = e.Id,
                    Name = e.Name
                })
                .ToListAsync();

            return Ok(new Responser<List<EmployeeResponse>>
            {
                data = list
            });
        }
    }
}
