﻿namespace TimesheetSystem.Request
{
    public class ListEmployeesRequest
    {
        // 無需任何屬性，僅用來與前端綁定空 JSON {}
    }
}
