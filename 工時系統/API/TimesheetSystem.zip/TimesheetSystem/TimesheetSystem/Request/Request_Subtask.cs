﻿using System.Text.Json.Serialization;

namespace TimesheetSystem.Request
{
    public class ListSubtaskTreeRequest
    {
        public int TopTaskId { get; set; }
    }

    public class ListTopLevelSubtaskRequest
    {
        public int TopTaskId { get; set; }
    }

    public class ListSubtaskChildrenRequest
    {
        public int ParentId { get; set; }
    }

    public class SubtaskDetailRequest
    {
        public int SubTaskId { get; set; }
    }

    public class UpdateSubtaskRequest
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public string Description { get; set; }
        public string Status { get; set; }
        public double EstimatedHours { get; set; }
        public int AssigneeId { get; set; }
        public int UpdatedById { get; set; }
    }

    public class CreateSubtaskRequest
    {
        public int ParentId { get; set; }
        public int TopTaskId { get; set; }
        public string Name { get; set; }
        public string Description { get; set; }
        public double EstimatedHours { get; set; }
        public string Status { get; set; }
        public int AssigneeId { get; set; }
        public int CreatedById { get; set; }
    }

    public class DeleteSubtaskRequest
    {
        public int Id { get; set; }
        public int DeletedById { get; set; }
    }
}
