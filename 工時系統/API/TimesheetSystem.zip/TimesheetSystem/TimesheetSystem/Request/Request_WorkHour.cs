﻿namespace TimesheetSystem.Request
{
    public class CreateWorkHourRequest
    {
        public int SubTaskId { get; set; }
        public int EmployeeId { get; set; }
        public decimal WorkHour { get; set; }
        public string? WorkDescription { get; set; }
        public DateTime CreatedAt { get; set; }
    }

    public class ListWorkHourRequest
    {
        public int? EmployeeId { get; set; }
        public int? SubTaskId { get; set; }
    }

    public class UpdateWorkHourRequest
    {
        public int Id { get; set; }
        public int SubTaskId { get; set; }
        public decimal WorkHour { get; set; }
        public string? WorkDescription { get; set; }
        public DateTime CreatedAt { get; set; }
    }

    public class DeleteWorkHourRequest
    {
        public int Id { get; set; }
    }
}
