﻿namespace TimesheetSystem.Request
{
    public class ListTopTaskRequest
    {
        public bool includeDeleted { get; set; } = false;
    }

    public class TopTaskDetailRequest
    {
        public int id { get; set; }
    }

    public class UpdateTopTaskRequest
    {
        public int id { get; set; }
        public string name { get; set; } = string.Empty;
        public string? description { get; set; }
        public decimal budget { get; set; }
        public int managerId { get; set; }
        public int updatedById { get; set; }
    }

    public class CreateTopTaskRequest
    {
        public string name { get; set; } = string.Empty;
        public string? description { get; set; }
        public decimal budget { get; set; }
        public int managerId { get; set; }
        public int createdById { get; set; }
    }

    public class DeleteTopTaskRequest
    {
        public int id { get; set; }
        public int deletedById { get; set; }
    }
}
